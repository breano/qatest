
describe('Test', function () {
   
    ///1 test to confirm title and desc
it('Comfirming Title and Description', () => {

    cy.visit('https://docs.google.com/forms/d/e/1FAIpQLSdSGEC9iMTjG8OHeVQ_bW5z8mqXVAJ-WibXjdWpDG-76w9jFw/viewform') 
    cy.wait(1000);
    cy.get('.freebirdFormviewerViewHeaderTitle').should('contain','Energy drink survey'); // Assertion for Confirming Title 
    cy.log('Energy drink survey');// displying Title in log
    cy.wait(1000); 
    cy.get('.freebirdFormviewerViewHeaderDescription').should('contain','To see people drinking habbits'); // Assertion for Confirming Description 
    cy.log('To see people drinking habbits'); // displying Description in log
    cy.wait(1000);
})

///2 submite without required fields
it('Submitting Without required Fields (*)',()=> {
    cy.visit('https://docs.google.com/forms/d/e/1FAIpQLSdSGEC9iMTjG8OHeVQ_bW5z8mqXVAJ-WibXjdWpDG-76w9jFw/viewform')
    cy.wait(700);
    cy.get('.freebirdFormviewerViewNavigationLeftButtons > .appsMaterialWizButtonEl > .appsMaterialWizButtonPaperbuttonContent').should('contain' ,'Enviar').click();
    cy.wait(700);
    cy.get('.freebirdFormviewerComponentsQuestionBaseErrorText').should('contain' ,'Esta pregunta es obligatoria');

})

/// 3 submit without email entered
it('Submitting without email entered',()=> {
    cy.visit('https://docs.google.com/forms/d/e/1FAIpQLSdSGEC9iMTjG8OHeVQ_bW5z8mqXVAJ-WibXjdWpDG-76w9jFw/viewform');
    cy.wait(700); 
    cy.get('#i8 > .appsMaterialWizToggleRadiogroupRadioButtonContainer > .appsMaterialWizToggleRadiogroupOffRadio').click();
    cy.wait(700); 
    cy.get(':nth-child(4) > .freebirdMaterialScalecontentInput > .appsMaterialWizToggleRadiogroupElContainer > .appsMaterialWizToggleRadiogroupEl > .appsMaterialWizToggleRadiogroupRadioButtonContainer > .appsMaterialWizToggleRadiogroupOffRadio').click(); // Selection option for "how likely are you to buy sugar full over sugar free"
    cy.wait(700);
    cy.get('#i39 > .quantumWizTogglePapercheckboxInnerBox').click(); // Selecting CheckBox for "Whats days would you drink energy drinks"
    cy.wait(700); 
    cy.get('.freebirdFormviewerViewNavigationLeftButtons > .appsMaterialWizButtonEl > .appsMaterialWizButtonPaperbuttonContent').should('contain' ,'Enviar').click(); // Comfirming Submit is clicked
    cy.wait(700);
    cy.get('.freebirdFormviewerComponentsQuestionBaseErrorText').should('contain' ,'Esta pregunta es obligatoria').click();
   


})

///4 testing email validation 
it('Submitting without proper email format',()=>{

    //open url
    cy.visit('https://docs.google.com/forms/d/e/1FAIpQLSdSGEC9iMTjG8OHeVQ_bW5z8mqXVAJ-WibXjdWpDG-76w9jFw/viewform');
    cy.wait(700); 

    ///select option for how often many days a week
    cy.get('#i11 > .appsMaterialWizToggleRadiogroupRadioButtonContainer > .appsMaterialWizToggleRadiogroupOffRadio').click();
    cy.wait(700); 

    //input incorrect email data
    cy.get('.quantumWizTextinputPaperinputInput').type('DummyText',{delay:200});
    cy.wait(1000);

    //fill in option how likely to buy sugar
    cy.get(':nth-child(4) > .freebirdMaterialScalecontentInput > .appsMaterialWizToggleRadiogroupElContainer > .appsMaterialWizToggleRadiogroupEl > .appsMaterialWizToggleRadiogroupRadioButtonContainer > .appsMaterialWizToggleRadiogroupOffRadio').click(); // Selection option for "how likely are you to buy sugar full over sugar free"
    cy.wait(700);
    cy.get(':nth-child(4) > .freebirdMaterialScalecontentInput > .appsMaterialWizToggleRadiogroupElContainer > .appsMaterialWizToggleRadiogroupEl > .appsMaterialWizToggleRadiogroupRadioButtonContainer > .appsMaterialWizToggleRadiogroupOffRadio').click(); // Selection option for "how likely are you to buy sugar full over sugar free"
    cy.wait(700);

    //select option for what days you drink
    cy.wait(700);
    cy.get('#i39 > .quantumWizTogglePapercheckboxInnerBox').click();
    cy.wait(700);
    cy.get('#i33 > .quantumWizTogglePapercheckboxInnerBox').click();
    cy.wait(800);

    ///confirming submit was clicked
    cy.get('.freebirdFormviewerViewNavigationLeftButtons > .appsMaterialWizButtonEl > .appsMaterialWizButtonPaperbuttonContent').should('contain', 'Enviar').click();
    cy.wait(700); 
    cy.get('#i19 > .freebirdFormviewerComponentsQuestionBaseErrorText').should('contain' ,'incorrect gmail'); // Comfirming Submit is clicked
    cy.wait(700);

})

/// 5 without selecting how many days in the week

it('Submitting without Q1 answered',()=>{

    //open url
    cy.visit('https://docs.google.com/forms/d/e/1FAIpQLSdSGEC9iMTjG8OHeVQ_bW5z8mqXVAJ-WibXjdWpDG-76w9jFw/viewform');
    cy.wait(700); 

//input correct email data
cy.get('.quantumWizTextinputPaperinputInput').type('DummyText@gmail.com',{delay:200});
cy.wait(700);

//fill in option how likely to buy sugar
cy.get(':nth-child(4) > .freebirdMaterialScalecontentInput > .appsMaterialWizToggleRadiogroupElContainer > .appsMaterialWizToggleRadiogroupEl > .appsMaterialWizToggleRadiogroupRadioButtonContainer > .appsMaterialWizToggleRadiogroupOffRadio').click(); // Selection option for "how likely are you to buy sugar full over sugar free"
cy.wait(700);
cy.get(':nth-child(4) > .freebirdMaterialScalecontentInput > .appsMaterialWizToggleRadiogroupElContainer > .appsMaterialWizToggleRadiogroupEl > .appsMaterialWizToggleRadiogroupRadioButtonContainer > .appsMaterialWizToggleRadiogroupOffRadio').click(); // Selection option for "how likely are you to buy sugar full over sugar free"
cy.wait(700);

    //select option for what days you drink
cy.wait(700);
cy.get('#i39 > .quantumWizTogglePapercheckboxInnerBox').click();
cy.wait(700);
cy.get('#i33 > .quantumWizTogglePapercheckboxInnerBox').click();
cy.wait(700);
/// verify  Esta pregunta es obligatoria

    ///confirming submit was clicked
cy.get('.freebirdFormviewerViewNavigationLeftButtons > .appsMaterialWizButtonEl > .appsMaterialWizButtonPaperbuttonContent').should('contain', 'Enviar').click();
cy.wait(700); 
cy.get('.freebirdFormviewerComponentsQuestionBaseErrorText').should('contain' ,'Esta pregunta es obligatoria'); // Comfirming Submit is clicked
 cy.wait(700);




//without selecting how likely 


//selecting more than 3 options for day 

})


/// 6 without selecting linear scale

it('Submitting without selecting linear scale',()=>{

    //open url
    cy.visit('https://docs.google.com/forms/d/e/1FAIpQLSdSGEC9iMTjG8OHeVQ_bW5z8mqXVAJ-WibXjdWpDG-76w9jFw/viewform');
    cy.wait(700); 

    cy.get('#i8 > .appsMaterialWizToggleRadiogroupRadioButtonContainer > .appsMaterialWizToggleRadiogroupOffRadio').click();
    cy.wait(700); 
//input correct email data
cy.get('.quantumWizTextinputPaperinputInput').type('DummyText@gmail.com',{delay:200});
cy.wait(700);


    //select option for what days you drink
cy.wait(700);
cy.get('#i39 > .quantumWizTogglePapercheckboxInnerBox').click();
cy.wait(700);
cy.get('#i33 > .quantumWizTogglePapercheckboxInnerBox').click();
cy.wait(700);
/// verify  Esta pregunta es obligatoria

    ///confirming submit was clicked
cy.get('.freebirdFormviewerViewNavigationLeftButtons > .appsMaterialWizButtonEl > .appsMaterialWizButtonPaperbuttonContent').should('contain', 'Enviar').click();
cy.wait(700); 
cy.get('.freebirdFormviewerComponentsQuestionBaseErrorText').should('contain' ,'Esta pregunta es obligatoria'); // Comfirming Submit is clicked
 cy.wait(700);




})

/// 7 selecting more than 3 options for days available 


it('Submittingafter selecting more than 3',()=>{

    //open url
    cy.visit('https://docs.google.com/forms/d/e/1FAIpQLSdSGEC9iMTjG8OHeVQ_bW5z8mqXVAJ-WibXjdWpDG-76w9jFw/viewform');
    cy.wait(700); 

    
    cy.get('#i8 > .appsMaterialWizToggleRadiogroupRadioButtonContainer > .appsMaterialWizToggleRadiogroupOffRadio').click();
    cy.wait(700); 
    


/// verify  Esta pregunta es obligatoria

//input correct email data
    cy.get('.quantumWizTextinputPaperinputInput').type('DummyText@gmail.com',{delay:200});
    cy.wait(700);


    //fill in option how likely to buy sugar
    cy.get(':nth-child(4) > .freebirdMaterialScalecontentInput > .appsMaterialWizToggleRadiogroupElContainer > .appsMaterialWizToggleRadiogroupEl > .appsMaterialWizToggleRadiogroupRadioButtonContainer > .appsMaterialWizToggleRadiogroupOffRadio').click(); // Selection option for "how likely are you to buy sugar full over sugar free"
    cy.wait(700);
    cy.get(':nth-child(4) > .freebirdMaterialScalecontentInput > .appsMaterialWizToggleRadiogroupElContainer > .appsMaterialWizToggleRadiogroupEl > .appsMaterialWizToggleRadiogroupRadioButtonContainer > .appsMaterialWizToggleRadiogroupOffRadio').click(); // Selection option for "how likely are you to buy sugar full over sugar free"
    cy.wait(700);

    
    //select option for what days you drink
    cy.wait(700);
    cy.get('#i39 > .quantumWizTogglePapercheckboxInnerBox').click();
    cy.wait(700);
    cy.get('#i33 > .quantumWizTogglePapercheckboxInnerBox').click();
    cy.wait(700);
    cy.get('#i42 > .quantumWizTogglePapercheckboxInnerBox').click();
    cy.wait(700);
    cy.get('#i45 > .quantumWizTogglePapercheckboxInnerBox').click();
    cy.wait(700);


    ///confirming submit was clicked
    cy.get('.freebirdFormviewerViewNavigationLeftButtons > .appsMaterialWizButtonEl > .appsMaterialWizButtonPaperbuttonContent').should('contain', 'Enviar').click();
    cy.wait(700); 
    cy.get('.freebirdFormviewerComponentsQuestionBaseErrorText').should('contain' ,'please select 3'); // Comfirming ERROR IS SHOW
    cy.wait(700);
    




})


//8 with correct data 


it('Submitting with correct data',()=>{

    //open url
    cy.visit('https://docs.google.com/forms/d/e/1FAIpQLSdSGEC9iMTjG8OHeVQ_bW5z8mqXVAJ-WibXjdWpDG-76w9jFw/viewform');
    cy.wait(700); 

    
    cy.get('#i8 > .appsMaterialWizToggleRadiogroupRadioButtonContainer > .appsMaterialWizToggleRadiogroupOffRadio').click();
    cy.wait(700); 
    


/// verify  Esta pregunta es obligatoria

//input correct email data
    cy.get('.quantumWizTextinputPaperinputInput').type('DummyText@gmail.com',{delay:200});
    cy.wait(700);


    //fill in option how likely to buy sugar
    cy.get(':nth-child(4) > .freebirdMaterialScalecontentInput > .appsMaterialWizToggleRadiogroupElContainer > .appsMaterialWizToggleRadiogroupEl > .appsMaterialWizToggleRadiogroupRadioButtonContainer > .appsMaterialWizToggleRadiogroupOffRadio').click(); // Selection option for "how likely are you to buy sugar full over sugar free"
    cy.wait(700);
    cy.get(':nth-child(4) > .freebirdMaterialScalecontentInput > .appsMaterialWizToggleRadiogroupElContainer > .appsMaterialWizToggleRadiogroupEl > .appsMaterialWizToggleRadiogroupRadioButtonContainer > .appsMaterialWizToggleRadiogroupOffRadio').click(); // Selection option for "how likely are you to buy sugar full over sugar free"
    cy.wait(700);

    
    //select option for what days you drink
    cy.wait(700);
    cy.get('#i39 > .quantumWizTogglePapercheckboxInnerBox').click();
    cy.wait(700);
    cy.get('#i33 > .quantumWizTogglePapercheckboxInnerBox').click();
    cy.wait(700);
    cy.get('#i42 > .quantumWizTogglePapercheckboxInnerBox').click();
    cy.wait(700);


    ///confirming submit was clicked
    cy.get('.freebirdFormviewerViewNavigationLeftButtons > .appsMaterialWizButtonEl > .appsMaterialWizButtonPaperbuttonContent').should('contain', 'Enviar').click();
    cy.wait(7000); 
    cy.get('.freebirdFormviewerViewResponseConfirmationMessage').should('contain', 'Se ha registrado tu respuesta.')




})
})
